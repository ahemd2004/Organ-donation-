document.getElementById('download').addEventListener('click', function () {
    const formData = `
    Registration Form\n
    ID: {{ user.user_id }}
    Name: {{ user.username }}
    Email: {{ user.email }}
    Phone: {{ user.telephone }}
    Date of Birth: {{ user.birthday }}
    Address: {{ user.country }}
    Status: {{ user.status }}
    `;

    const blob = new Blob([formData], { type: 'text/plain' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'registration_form.txt';
    link.click();
    URL.revokeObjectURL(link.href);
});
document.getElementById('logoutButton').addEventListener('click', () => {
    fetch('/logout', { method: 'GET' })
        .then(() => {
            alert('Logged out successfully.');
            window.location.href = '/login';
        })
});